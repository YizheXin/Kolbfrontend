// app/api/storage/getFiles/route.ts
import { NextRequest } from 'next/server';
import { Storage } from '@google-cloud/storage';
import { formatGCSUrl } from '@/utils/gcsUrl';
import { parseSize } from '@/utils/getSize';

// Initialize storage using ADC (Application Default Credentials)
const storage = new Storage();
const csvBucketName = process.env.GCP_CSV_BUCKET || 'ics-analysis-dev-kolbs';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const folder = searchParams.get('folder');

    if (!folder) {
      return Response.json(
        {
          success: false,
          files: [],
          message: "Folder parameter is required",
        },
        { status: 400 }
      );
    }

    console.log("Retrieving CSV files from folder:", folder);
    const bucket = storage.bucket(csvBucketName);
    const [files] = await bucket.getFiles({
      prefix: `${folder}/`,
      delimiter: '/',
    });

    // Filter and process CSV files
    const fileList = await Promise.all(
      files
        .filter((file) => {
          const isNotFolder = !file.name.endsWith('/');
          const isCSV = file.name.toLowerCase().endsWith('.csv');
          return isNotFolder && isCSV;
        })
        .map(async (file) => {
          try {
            const [metadata] = await file.getMetadata();
            const sizeInBytes = parseSize(metadata.size);
            const url = formatGCSUrl(csvBucketName, folder, file.name);
            return {
              name: file.name.split('/').pop() || '',
              timeCreated: metadata.timeCreated || 'N/A',
              size: formatFileSize(sizeInBytes),
              type: 'csv',
              url,
              metadata: {
                contentType: metadata.contentType,
                updated: metadata.updated,
              },
            };
          } catch (error) {
            console.error("Error fetching metadata for file:", file.name, error);
            return null;
          }
        })
    );

    return Response.json({
      success: true,
      files: fileList.filter(Boolean), // Filter out any null results
      message: "CSV files retrieved successfully.",
    });
  } catch (err: any) {
    console.error('Error retrieving CSV files:', err);
    return Response.json(
      {
        success: false,
        files: [],
        message: "Failed to retrieve CSV files.",
        error: err.message,
      },
      { status: 500 }
    );
  }
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
